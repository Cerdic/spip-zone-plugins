<?php


	/**
	 * SPIP-Lettres
	 *
	 * Copyright (c) 2006-2009
	 * Agence Artégo http://www.artego.fr
	 *  
	 * Ce programme est un logiciel libre distribue sous licence GNU/GPLv3.
	 * Pour plus de details voir http://www.gnu.org/licenses/gpl-3.0.html
	 *  
	 **/


	$GLOBALS[$GLOBALS['idx_lang']] = array(

        'erreur_choix_article_valeur' => 'Cuidado una error de formateo en su selección se detectó',
        'erreur_choix_objets' => 'Cuidado solo puede elegir artículos',
        'erreur_choix_objets_id' => 'Cuidado necesita un nombre de usuario positivo',
	
        'label_choisir_articles' => 'Artículo(s) junto(s) a la carta',
	);


?>
