<?php


	/**
	 * SPIP-Lettres
	 *
	 * Copyright (c) 2006-2009
	 * Agence Artégo http://www.artego.fr
	 *  
	 * Ce programme est un logiciel libre distribue sous licence GNU/GPLv3.
	 * Pour plus de details voir http://www.gnu.org/licenses/gpl-3.0.html
	 *  
	 **/


	$GLOBALS[$GLOBALS['idx_lang']] = array(

        'erreur_choix_article_valeur' => 'Be careful a formatting error in your selection has been found',
        'erreur_choix_objets' => 'Be careful you can only choose articles',
        'erreur_choix_objets_id' => 'Be careful you need a positive ID user name',
	
        'label_choisir_articles' => 'Article(s) joined to the letter',
	);


?>
