<?php


	/**
	 * SPIP-Lettres
	 *
	 * Copyright (c) 2006-2009
	 * Agence Artégo http://www.artego.fr
	 *  
	 * Ce programme est un logiciel libre distribue sous licence GNU/GPLv3.
	 * Pour plus de details voir http://www.gnu.org/licenses/gpl-3.0.html
	 *  
	 **/


	$GLOBALS[$GLOBALS['idx_lang']] = array(

        'erreur_choix_article_valeur' => 'Attention une erreur de formatage dans votre selection est présente',
        'erreur_choix_objets' => 'Attention vous ne pouvez choisir que des articles',
        'erreur_choix_objets_id' => 'Attention vous devez avoir un identifiant d\'id positif',
	
        'label_choisir_articles' => 'Article(s) affecté(s) à la lettre',
	);


?>
