<?php
require('GifSplit.class.php');
$sg = new GifSplit('test.gif', 'GIF', 'frame');
/*
   Source image formats animated GIF

   Destination image formats,
    'GIF' -> GIF image
    'PNG' -> PNG image
    'JPG' -> JPG/JPEG image
    'BMP' -> BMP image

   Destination name of frames

   Error reports,
    'error #1' -> Not GIF file
    'error #2' -> Unable to open sourcefile
    'error #3' -> Unable to write destination file(s)
    'ok' -> Splitting succeeded

   Special report,
    'Unrecognized byte code xxxx'
*/
switch($sg->getReport())
{
	case "error #1":
		echo "<script type=\"text/javascript\">alert('This image is not GIF image!');</script>";
	break;
	case "error #2":
		echo "<script type=\"text/javascript\">alert('Unable to open source image\\nMaybe internal server error!');</script>";
	break;
	case "error #2":
		echo "<script type=\"text/javascript\">alert('Unable to write destination frames\\nMaybe internal server error!');</script>";
	break;
	case "ok":
		;
		/* Internal image processing routines, etc. */
	break;
}
?>
