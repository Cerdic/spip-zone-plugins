<?php
	// ================================================
	// PHP image browser - iBrowser 
	// ================================================
	// iBrowser dialog - load message
	// ================================================
	// Developed: net4visions.com
	// Copyright: net4visions.com
	// License: GPL - see readme.txt
	// (c)2005 All rights reserved.
	// ================================================
	// Revision: 1.0                   Date: 09/12/2005
	// ================================================	
?>
<div align="center" id="dialogLoadMessage" style="display:block;">
  <table width="100%" height="90%">
    <tr>
      <td align="center" valign="middle"><div id="loadMessage">Please wait while loading...</div></td>	  
    </tr>
  </table>
</div>