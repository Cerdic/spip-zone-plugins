// UK lang variables
tinyMCE.addToLang('ibrowser',{
desc : 'Insert image'
});