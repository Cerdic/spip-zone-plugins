tinyMCE.addToLang('ibrowser',{
desc : 'Ins�rer une image'
});