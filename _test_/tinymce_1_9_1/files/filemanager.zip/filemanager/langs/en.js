// UK lang variables
tinyMCE.addToLang('filemanager',{
desc : 'Insert File Link'
});