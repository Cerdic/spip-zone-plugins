tinyMCE.addToLang('filemanager',{
desc : 'Ins&eacute;rer un lien vers un fichier'
});